package com.br.testapithree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestApiThreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
