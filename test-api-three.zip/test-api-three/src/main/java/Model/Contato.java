package Model;

public class Contato {

    private String tipo;
    private String valor;

    public Contato() {
    }

    public Contato(String tipo, String valor) {
        this.tipo = tipo;
        this.valor = valor;
    }
}
